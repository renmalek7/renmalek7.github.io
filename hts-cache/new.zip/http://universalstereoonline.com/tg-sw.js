<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/universalstereoonline.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.6"}};
			/*! This file is auto-generated */
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://universalstereoonline.com/wp-includes/css/dist/block-library/style.min.css?ver=5.4.6' type='text/css' media='all' />
<link rel='https://api.w.org/' href='http://universalstereoonline.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://universalstereoonline.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://universalstereoonline.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.6" />
<link rel="dns-prefetch" href="//api.tunegenie.com">
<link rel="preconnect" href="https://api.tunegenie.com">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="description" content="Grupo Radio Centro" />
<meta name="viewport" content="width=deevice-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<head>
	<title>
				</title>
	
	<!-- opengraph editar app_id con cada sitio -->
	<meta property="fb:app_id" content="175188695967073" />  
	<meta property="fb:admins" content="709943063" /> 
	<meta property="og:title" content="" />   
	<meta property="og:site_name" content="Universal Stereo Online" />  
	<meta property="og:description" content="Universal Stereo Online - Música de Universal 88.1 FM las 24 horas con menos interrupciones!" />  
	<meta property="og:type" content="website" />  
		<meta property="og:image" content="" />	
	<!-- #opengraph -->
	
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://universalstereoonline.com/feed/" />
	<link rel="pingback" href="http://universalstereoonline.com/xmlrpc.php" />
		<!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
		<!-- CSS -->
	<link rel="stylesheet" type="text/css" media="all" href="http://universalstereoonline.com/wp-content/themes/radio/style.css" />
		<!-- google fonts -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:500,800,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Pathway+Gothic+One' rel='stylesheet' type='text/css'>
		
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	

		<script type='text/javascript'>
		  var googletag = googletag || {};
		  googletag.cmd = googletag.cmd || [];
		  (function() {
			var gads = document.createElement('script');
			gads.async = true;
			gads.type = 'text/javascript';
			var useSSL = 'https:' == document.location.protocol;
			gads.src = (useSSL ? 'https:' : 'http:') +
			  '//www.googletagservices.com/tag/js/gpt.js';
			var node = document.getElementsByTagName('script')[0];
			node.parentNode.insertBefore(gads, node);
		  })();
		</script>

		<script type='text/javascript'>
		  googletag.cmd.push(function() {
		   var mapping = googletag.sizeMapping().
		   addSize([0, 0], [320, 50]).
		   addSize([600, 0], [468, 60]).
		   addSize([980, 0], [728, 90]).
		   build();

			googletag.defineSlot('/39772251/Universal_Top', [[468, 60], [728, 90], [320, 50]], 'div-gpt-ad-top').defineSizeMapping(mapping).addService(googletag.pubads());
			googletag.defineSlot('/39772251/Universal_Box', [300, 250], 'div-gpt-ad-box').addService(googletag.pubads());
			googletag.defineSlot('/39772251/Universal_BoxG', [300, 600], 'div-gpt-ad-boxg').addService(googletag.pubads());
			googletag.defineSlot('/39772251/Universal_Foot', [[468, 60], [728, 90], [320, 50]], 'div-gpt-ad-foot').defineSizeMapping(mapping).addService(googletag.pubads());
			googletag.pubads().enableSingleRequest();
			googletag.enableServices();
		  });
		</script>

	
	<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5ca25cbc9b272f00119aba9a&product=inline-share-buttons' async='async'></script>
	
</head>
<body>
	<style type="text/css">
	@media screen and (min-width:960px){ 
		body{background-image: url('http://universalstereoonline.com/wp-content/themes/radio/images/bg.jpg');}
	}
	</style>
<!-- CONTENEDOR -->
<div id="contenedor">
		
		<!-- EDITAR PARA CADA ESTACION -->

	<!-- CABECERA PRINCIPAL -->
	<div id="cabecera_principal">
		<!-- logo_desktop -->
		<div id="logo_desktop">
		<a href="/"><img src="http://universalstereoonline.com/wp-content/themes/radio/images/logo.png"/></a>
		</div> 
		<!-- #logo -->
		<!-- leaderboard -->
		<div id="leaderboard"> <br><br>
		<!-- EDITAR PARA CADA ESTACION -->
							
			    <div id="ad_top">
					<!-- /39772251/Universal_Top -->
						<div id='div-gpt-ad-top'>
						<script type='text/javascript'>
						googletag.cmd.push(function() { googletag.display('div-gpt-ad-top'); });
						</script>
						</div>				
				</div>
		</div> 
		<!-- #leaderboard -->
	</div> 
	<!-- #CABECERA PRINCIPAL -->
	<!-- MENU -->

	<!-- #MENU -->	<!-- PORTADA -->
	<div id="portada">
		<!-- rotativo -->
		<div id="rotativo">
			<div id="owl-demo" class="owl-carousel owl-theme">
								<a href="javascript:tgmp.playStream()"><img width="620" height="337" src="http://universalstereoonline.com/wp-content/uploads/2020/10/alexa_uso-620x337.jpg" class="attachment-rotativo size-rotativo wp-post-image" alt="" /></a>				<a href="javascript:tgmp.playStream()"><img width="620" height="337" src="http://universalstereoonline.com/wp-content/uploads/2020/05/uso2020_620x337.jpg" class="attachment-rotativo size-rotativo wp-post-image" alt="" srcset="http://universalstereoonline.com/wp-content/uploads/2020/05/uso2020_620x337.jpg 620w, http://universalstereoonline.com/wp-content/uploads/2020/05/uso2020_620x337-300x163.jpg 300w" sizes="(max-width: 620px) 100vw, 620px" /></a></div>
			<style type="text/css">
				#owl-demo .item img{
				display: block;
				width: 100%;
				height: auto;
				}
			</style>
		</div>
		<!-- #rotativo -->
		<!-- rot_banner -->
		<div id="rot_banner"><!-- EDITAR PARA CADA ESTACION -->
			<a href="javascript:tgmp.playStream()"><img src="http://universalstereoonline.com/wp-content/themes/radio/images/transmision_envivo.png" width="300" height="80" /></a>			
				<!-- /39772251/Universal_Box -->
				<div id='div-gpt-ad-box' style='height:250px; width:300px; margin-left: auto; margin-right: auto;'>
				<script type='text/javascript'>
				googletag.cmd.push(function() { googletag.display('div-gpt-ad-box'); });
				</script>
				</div>	
		</div> 
		<!-- #rot_banner -->
	</div> 
	<!-- #PORTADA -->
	<!-- CONTENIDOS -->
	<div id="contenidos">	
		<!-- tunegenie -->
			<div id="tunegenie">
				<p class='espaciado'>
					<i class="fa fa-music"></i>
					<p class='contenidos_title'>Últimas Canciones</p>
				</p>


		<td-songhistory
          id="td-songhistory"
          station="XERC_FM"
          songsdisplayed="5"
          highlightcolor="#FFF"
          buybtnvisible= "false"				
          primarycolor="#000"
          headerbgcolor= "#fff"
          secondarycolor="#FFF"
		  timeplayedvisible ="true"
          onappready="appReady"
          >
  		</td-songhistory>

		<script>

    var widgetSongHistory;

    //onappready callback function
    function appReady( widgetObjectInstance ){
        widgetSongHistory = widgetObjectInstance;
    }

		</script>

<script src="//widgets.listenlive.co/1.0/tdwidgets.min.js"></script>		
		
		
			</div>
		<!-- #tunegenie -->
		<!-- Banner Home Box Grande -->
			<div id="banner_home_boxg">
				<!-- /39772251/Universal_BoxG -->
				<div id='div-gpt-ad-boxg'>
				<script type='text/javascript'>
				googletag.cmd.push(function() { googletag.display('div-gpt-ad-boxg'); });
				</script>
				</div>
			</div>


		<!-- #Banner Home Box Grande -->			
		<!-- facebook 
			<div id="facebook">
				<p class='espaciado'>
					<i class="fa fa-facebook-square" aria-hidden="true"></i>
					<p class='contenidos_title'>Facebook</p>
				</p>
<div class="fb-page" data-href="https://www.facebook.com/Universal881/" data-tabs="timeline" data-height="404" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/Universal881/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Universal881/">Universal 88.1 FM</a></blockquote></div>
			</div>
		-->
		<!-- eventos
			<div id="eventoss">
				<p class='espaciado'>
					<i class="fa fa-calendar"></i>
					<p class='contenidos_title'>Eventos</p>
				</p>
				<a href="https://queen-el-origen.boletia.com/" target="_blank" rel="noopener">
					<img src="http://queenradiouniversal.com/wp-content/uploads/2019/05/queen_origen_600x808.jpg" alt="" width="300px" class="alignnone size-full wp-image-53" /></a>
			</div>
		<!-- #eventos -->
		<!-- concierto
			<div id="concierto">
		<img src="wp-content/uploads/2019/04/banner-mick-rock-1.jpg" alt="" width="100%" class="alignnone size-full wp-image-52" />		
			</div>
		<!-- #concierto -->	
	</div> 
	<!-- #CONTENIDOS -->	

	<!-- FOOTER -->
	<!-- FOOTER -->
	<footer id="inferior">
			<div class='centrado'>	
				<br>
				<!-- redes 		<div class="sharethis-inline-follow-buttons"></div> -->
				
				<br><a href="http://radiocentro.com" target="_blank">
				Copyright © 2021 Grupo Radio Centro. Todos los derechos reservados.</a>
		    </div><br>
		<!-- BANNER -->
			<div id="banner_footer">
			<div class='centrado'>

				<!-- /39772251/Universal_Foot -->
				<div id='div-gpt-ad-foot'>
				<script type='text/javascript'>
				googletag.cmd.push(function() { googletag.display('div-gpt-ad-foot'); });
				</script>
				</div>
				
			</div>
			</div>
		<br>
		</div>	
		<!-- #BANNER -->
	</footer> 
	<!-- #FOOTER -->
</div> 
<!-- #CONTENEDOR -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	<script type='text/javascript' src='http://universalstereoonline.com/wp-includes/js/wp-embed.min.js?ver=5.4.6'></script>
<script type="text/javascript">
  if ('serviceWorker' in navigator) {
    // google analytics
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                            })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-7150119-1', 'auto', 'm2gTracker');
    navigator.serviceWorker.getRegistrations().then(function (registrations) {
      if (registrations.length) {
        for(let registration of registrations) {
          var tg_brand = "xerc2";
          // unregister old version
          if (registration.active.scriptURL.endsWith('tg-sw.js') || registration.active.scriptURL.endsWith('tg2-sw.js')) {
            registration.unregister().then(function(success) {
              if (success) {
                ga('m2gTracker.send', 'event', tg_brand, 'pwa/unregister', 'wordpress');
                console.log('removed service worker');
              }
            }).catch(function(err) {
              ga('m2gTracker.send', 'event', tg_brand, 'pwa/unregister/error', 'wordpress');
              console.log('remove sw failed.');
            });
          }
        }
      }
    }).catch(function(err) {
      console.log('get registrations failed: ' + error);
    });
  }
</script>
<!-- TuneGenie WP plugin 2.0.1 -->
<script type="text/javascript" class="_tgmp_p">
function onTuneGenieMediaPlayerLoaded() {
    window.tgmp=new TuneGenieMediaPlayer('playerbar', {
        brand: "xerc2",
    });
    tgmp.go();
    window.tgmp_rc = new TuneGenieRC(tgmp);
    tgmp_rc.recentSongWidget(document.getElementById('tgrecent'),{});
    tgmp_rc.nowPlayingWidget(document.getElementById('tgnowplaying'),{});
    tgmp_rc.podcasts(document.getElementById('tgpodcasts'));
    tgmp_rc.podcast(document.getElementsByClassName('tgpodcast'));
}
</script>
<script type="text/javascript"  class="_tgmp_p" async src="https://b3.tunegenie.com/js/loader2.min.js"></script>

<!-- Default Statcounter code for Universal Stereo Online
http://universalstereoonline.com -->
<script type="text/javascript">
var sc_project=10177845; 
var sc_invisible=1; 
var sc_security="e222d0da"; 
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="https://statcounter.com/" target="_blank"><img
class="statcounter"
src="https://c.statcounter.com/10177845/0/e222d0da/1/"
alt="Web Analytics"></a></div></noscript>
<!-- End of Statcounter Code -->

</body>


	
<!-- Start of Analytics Code -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-5332840-22', 'auto');
ga('require', 'displayfeatures');
ga('send', 'pageview');

</script>
<!-- End of Analytics Code -->



	<!-- owl -->
	<script src="http://universalstereoonline.com/wp-content/themes/radio/owl/owl.carousel.js"></script>
	<script>
	$(document).ready(function() {
 
		$("#owl-demo").owlCarousel({
 
		autoPlay : 5000,
		stopOnHover : true,
		navigation: false,
		slideSpeed : 300,
		paginationSpeed : 200,
		goToFirstSpeed : 1000,
		singleItem : true,
		autoHeight : true,
		});
 
	});
	</script>
</html>	<!-- #FOOTER -->